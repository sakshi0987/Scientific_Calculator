﻿using System;
using System.Collections.Generic;

namespace ArithmeticOperations
{
    public class ArithmeticExpression
    {
        public static bool HasHigherPrecedence(char operator1, char operator2)
        {
            if ((operator1 == '/' && operator2 == '*') ||
                (operator1 == '-' && operator2 == '+') ||
                (operator1 == '^' && operator2 == '^') ||
                (operator1 == '^' && (operator2 == '*' || operator2 == '/' || operator2 == '+' || operator2 == '-')) ||
                ((operator1 == '*' || operator1 == '/') && (operator2 == '+' || operator2 == '-')))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static decimal PerformOperation(decimal a, decimal b, char operation)
        {
            switch (operation)
            {
                case '+':
                    return a + b;
                case '-':
                    return a - b;
                case '*':
                    return a * b;
                case '/':
                    if (b == 0)
                    {
                        throw new DivideByZeroException("Cannot divide by zero.");
                    }
                    return a / b;
                case '^':
                    return (decimal)Math.Pow((double)a, (double)b);
            }
            return 0;
        }

        public static decimal EvaluateExpression(string expression)
        {
            return EvaluateBODMAS(expression);
        }

        static decimal EvaluateBODMAS(string expression)
        {
            int index = 0;
            Stack<char> operators = new Stack<char>(10);
            Stack<decimal> operands = new Stack<decimal>(10);
            bool negativeAtFirst = false, nextIsNumber = true;
            string number = "";

            while (index < expression.Length)
            {
                if (expression[index] == '-' && expression[index + 1] == '(')
                {
                    negativeAtFirst = false;
                }

                if ((negativeAtFirst == true && expression[index] == '-' && expression[index + 1] != '(') ||
                    (expression[index] >= '0' && expression[index] <= '9') ||
                    expression[index] == '.' || expression[index] == 'E')
                {
                    if (negativeAtFirst == true && expression[index] == '-')
                    {
                        index++;
                    }
                    number += expression[index];

                    if (expression[index] == 'E')
                    {
                        index++;
                        number += expression[index];
                    }

                    if (index == expression.Length - 1 || (index < expression.Length - 1 && !((expression[index + 1] >= '0' && expression[index + 1] <= '9') 
                        || expression[index + 1] == '.' || expression[index + 1] == 'E')))
                    {
                        nextIsNumber = false;
                    }
                    if (nextIsNumber == false)
                    {
                        if (negativeAtFirst == true)
                        {
                            operands.Push(-(decimal)Convert.ToDouble(number));
                            number = "";
                            nextIsNumber = true;
                        }
                        else
                        {
                            operands.Push((decimal)Convert.ToDouble(number));
                            number = "";
                            nextIsNumber = true;
                        }
                        negativeAtFirst = false;
                    }
                }
                else if (expression[index] == '+' || expression[index] == '-' || expression[index] == '/' || expression[index] == '*' || expression[index] == '^')
                {
                    if (operands.Count == 0 || expression[index - 1] == '(')
                    {
                        operands.Push(0);
                    }
                    if (operators.Count == 0)
                    {
                        operators.Push(expression[index]);
                    }
                    else
                    {
                        if (HasHigherPrecedence(operators.Peek(), expression[index]) == true)
                        {
                            operators.Push(expression[index]);
                        }
                        else
                        {
                            while (operators.Count != 0 && (HasHigherPrecedence(operators.Peek(), expression[index]) == false))
                            {
                                decimal b = operands.Pop();
                                decimal a = operands.Pop();
                                operands.Push(PerformOperation(a, b, operators.Peek()));
                                operators.Pop();
                            }
                            operators.Push(expression[index]);
                        }
                    }
                }
                else if (expression[index] == '(' || expression[index] == ')')
                {
                    if (expression[index] == '(')
                    {
                        operators.Push(expression[index]);
                    }
                    else
                    {
                        while (operators.Peek() != '(')
                        {
                            decimal b = operands.Pop();
                            decimal a = operands.Pop();
                            operands.Push(PerformOperation(a, b, operators.Peek()));
                            operators.Pop();
                        }
                        operators.Pop();
                    }
                }
                index++;

                if (index == expression.Length && operators.Count != 0)
                {
                    while (operators.Count != 0)
                    {
                        decimal b = operands.Pop();
                        decimal a = operands.Pop();
                        operands.Push(PerformOperation(a, b, operators.Peek()));
                        operators.Pop();
                    }
                }
            }
            return operands.Peek();
        }
    }
}

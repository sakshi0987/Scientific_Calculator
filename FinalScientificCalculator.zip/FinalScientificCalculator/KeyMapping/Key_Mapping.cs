﻿using System;

namespace KeyMapping
{
    public class Key_Mapping
    {
        public static void ShowKeysWithFunctions()
        {
            Console.SetCursorPosition(0, 4);
            KeyMapWithFunctions();
            Console.SetCursorPosition(0, 0);
        }
        static void KeyMapWithFunctions()
        {
            Console.WriteLine("\nMemory Functions:");
            Console.WriteLine("B : Memory Clear\t\t m : MR\t\t Shift+m : M+");
            Console.WriteLine("ctrl+m : MS\t\t alt+m : M-");

            Console.WriteLine("\nTrigonometric Functions:");
            Console.WriteLine("S : Trigonometry Sin\t\t CTRL+S : Hyperbolic SinH\t\t ALT+S : Inverse Sin^(-1)");
            Console.WriteLine("C : Trigonometry Cos\t\t CTRL+C : Hyperbolic CosH\t\t ALT+C : Inverse Cos^(-1)");
            Console.WriteLine("T : Trigonometry Tan\t\t CTRL+T : Hyperbolic TanH\t\t ALT+T : Inverse Tan^(-1)");
            Console.WriteLine("O : Trigonometry Cot\t\t Ctrl+O : Hyperbolic CotH\t\t Alt+O : Inverse Cot^(-1)");
            Console.WriteLine("N : Trigonometry Sec\t\t Ctrl+N : Hyperbolic SecH\t\t Alt+N : Inverse Sec^(-1)");
            Console.WriteLine("Q : Trigonometry Cosec\t\t Ctrl+N : Hyperbolic CosecH\t\t Alt+N : Inverse Cosec^(-1)");

            Console.WriteLine("\nPower Functions:");
            Console.WriteLine("P : Power Symbol\t\t Shift+P : 2^x\t\t Ctrl+p : 10^x");
            Console.WriteLine("ALt+p : Pi Value");

            Console.WriteLine("\nOther Functions:");
            Console.WriteLine("L : Natural Log \t\t Shift+L : Log");
            Console.WriteLine("A : Absolute Function\t\t E : e^x\t\t Shift+E : Value of E");
            Console.WriteLine("Z : Changing the angle unit\t F : Factorial\t\t [ : Floor Value");
            Console.WriteLine("] : Ceiling Value\t\t G : Random Number\t\t R : Square");
            Console.WriteLine("Shift + R : Cube\t\t J : Square Root\t\t Shift + J : Cube Root");
            Console.WriteLine("V : F-E Toggling");
            Console.WriteLine("- : Negate");

            Console.WriteLine("Delete : C and CN");
            Console.WriteLine("\nExit:");
            Console.WriteLine("Esc : Exit");
            Console.ReadKey();
        }
    }
}

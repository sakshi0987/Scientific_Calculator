﻿using System;
using System.IO;
namespace PowerOperations
{
    public class Power
    {
        //Power Functions
        public static double Exponentiation(double baseValue, double exponent)
        {
            return Math.Pow(baseValue, exponent);
        }

        public static double Root(double baseValue, double rootValue)
        {
            return Math.Pow(baseValue, 1.0 / rootValue);
        }

        public static double SquareRoot(double number)
        {
            if (number < 0)
            {
                throw new ArgumentException("Invalid input");
            }
            return Math.Sqrt(number);
        }

        public static double CubeRoot(double number)
        {
            if (number < 0)
            {
                number = Math.Abs(number);
                double temp = Math.Pow(number, 1.0 / 3.0);
                return (0 - temp);
            }
            return Math.Pow(number, 1.0 / 3.0);
        }

        public static double LogBase10(double x)
        {
            return Math.Log10(x);
        }

        public static double NaturalLog(double x)
        {
            return Math.Log(x);
        }

        public static double EPowerx(double x)      // e power x
        {
            return Math.Exp(x);
        }

        public static double CalculateFactorial(double number)
        {
            if (number < 0)
            {
                throw new InvalidDataException("Invalid input: Factorial is defined for non-negative numbers");
            }
            return CalculateGamma(number + 1);
        }

        static readonly int CoefficientsCount = 7;
        static readonly double[] LanczosCoefficients = { 0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7 };

        static double CalculateGamma(double value)
        {
            if (value < 0.5)
            {
                return Math.PI / (Math.Sin(Math.PI * value) * CalculateGamma(1 - value));
            }

            value -= 1;
            double sum = LanczosCoefficients[0];
            for (var i = 1; i < CoefficientsCount + 2; i++)
            {
                sum += LanczosCoefficients[i] / (value + i);
            }

            double term = value + CoefficientsCount + 0.5;
            return Math.Sqrt(2 * Math.PI) * (Math.Pow(term, value + 0.5)) * Math.Exp(-term) * sum;
        }
        //Functions
        public static double AbsoluteValue(double input)
        {
            return Math.Abs(input);
        }

        public static double FloorValue(double input)
        {
            return Math.Floor(input);
        }
        public static double CeilingValue(double input)
        {
            return Math.Ceiling(input);
        }

        public static double GenerateRandom()
        {
            return new Random().NextDouble();
        }

        public static double ConvertToDMS(double angle1)
        {
            int degrees = (int)Math.Floor(angle1);
            double minutes = (angle1 - degrees) * 60;
            int minutesInt = (int)Math.Floor(minutes);
            double seconds = (minutes - minutesInt) * 60;
            double result = degrees + minutesInt / 100.0 + seconds / 10000.0;
            return result;
        }
        public static double DMSToDegree(double angle1)
        {
            int degrees = (int)Math.Floor(angle1);
            double minutes = (angle1 - degrees);
            double result = degrees + (minutes / 60);
            return result;
        }
        public static string ChangeToScientificNotation(decimal number)
        {
            string scientificNotation = String.Format("{0:0.############################e+0}", number);
            return scientificNotation;
        }
    }
}

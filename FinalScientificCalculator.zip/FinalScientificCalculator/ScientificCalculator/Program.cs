﻿using System;
using System.Text;
using ArithmeticOperations;
using PowerOperations;
using TrignometricOperations;
using KeyMapping;

namespace ScientificCalculator
{
    internal class Program
    { 
        static bool IsNextInput = false;                       // input after an output
        static bool IsScientificNotation = false;
        static bool checkMemory = false;
        static bool functionKeyPressed = false;
        static bool firstOccuranceOfOperator;
        static bool toCheckOpenBracket = false;

        static int angleModeTapCount = 0;                               // to check toggle count of angle(DEG,RAD,GRAD)
        static int thatIndex;
        static int ScientificNotationCount = 0;            // to calculate F_E toggle count
        static int OpenBracketCount = 0;
        static int ToDisplayOpenBracketCount = 0;
        static int infunctionOnce = 0;
        static double memory = 0;
        static decimal OutputConverted;

        static string angleMeasureMode = "DEG";
        static string ScientificNotationStatus = "F-E";
        static string enteredAngle;
        static string currentInput = "";
        static StringBuilder outputString = new StringBuilder();
        static StringBuilder showFunctions = new StringBuilder();

        static void Main()
        {
            Console.Title = "!WelcomeTO Scientific Calculator!";
            Console.TreatControlCAsInput = true;
            Console.CursorVisible = false;
            ConsoleKeyInfo input;
            bool operatorAfterOperator;
            decimal result = 0;

          //  Key_Mapping.ShowKeysWithFunctions();
            Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
            Console.WriteLine(outputString.ToString());
            Console.WriteLine(showFunctions.ToString());
            Console.WriteLine(IsScientificNotation
                    ? (string.IsNullOrEmpty(currentInput) ? Power.ChangeToScientificNotation(0)
                    : (Decimal.TryParse(currentInput, out OutputConverted) ? Power.ChangeToScientificNotation(OutputConverted)
                    : Power.ChangeToScientificNotation((decimal)Convert.ToDouble(currentInput))))
                    : (string.IsNullOrEmpty(currentInput) ? "0" : currentInput));

            while (true)
            {
                do
                {
                    input = Console.ReadKey(true);
                    operatorAfterOperator = false;
                    string currentstring = Value(input);
                    Console.Clear();
                 //   Key_Mapping.ShowKeysWithFunctions();

                    Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                    Console.WriteLine(outputString.ToString());
                    Console.WriteLine(showFunctions.ToString());
                    Console.WriteLine(IsScientificNotation
                            ? (string.IsNullOrEmpty(currentInput) ? Power.ChangeToScientificNotation(0)
                            : (Decimal.TryParse(currentInput, out OutputConverted) ? Power.ChangeToScientificNotation(OutputConverted)
                            : Power.ChangeToScientificNotation((decimal)Convert.ToDouble(currentInput))))
                            : (string.IsNullOrEmpty(currentInput) ? "0" : currentInput));

                    // For multiple sequential operator
                    if (IsOperator(currentstring) && outputString.Length != 0 && IsOperator(outputString[outputString.Length - 1].ToString()) && firstOccuranceOfOperator && !functionKeyPressed)
                    {
                        operatorAfterOperator = true;
                        showFunctions.Remove(showFunctions.Length - 1, 1);
                        outputString.Remove(outputString.Length - 1, 1);
                        outputString.Append(currentstring);
                        showFunctions.Append(currentstring);
                        Console.Clear();
                     //   Key_Mapping.ShowKeysWithFunctions();

                        Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                        Console.WriteLine(outputString.ToString());
                        Console.WriteLine(showFunctions.ToString());
                        Console.WriteLine(IsScientificNotation
                            ? (string.IsNullOrEmpty(currentInput) ? Power.ChangeToScientificNotation(0)
                            : (Decimal.TryParse(currentInput, out OutputConverted) ? Power.ChangeToScientificNotation(OutputConverted)
                            : Power.ChangeToScientificNotation((decimal)Convert.ToDouble(currentInput))))
                            : (string.IsNullOrEmpty(currentInput) ? "0" : currentInput));
                    }
                    // if starting input is operator , append 0 in output
                    else if (IsOperator(currentstring) && outputString.Length == 0 && currentInput.Length == 0)
                    {
                        operatorAfterOperator = true;
                        outputString.Append("0");
                        showFunctions.Append("0");
                        outputString.Append(currentstring);
                        showFunctions.Append(currentstring);
                        Console.Clear();
                      //  Key_Mapping.ShowKeysWithFunctions();

                        Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                        Console.WriteLine(outputString.ToString());
                        Console.WriteLine(showFunctions.ToString());
                        Console.WriteLine(IsScientificNotation
                            ? (string.IsNullOrEmpty(currentInput) ? Power.ChangeToScientificNotation(0)
                            : (Decimal.TryParse(currentInput, out OutputConverted) ? Power.ChangeToScientificNotation(OutputConverted)
                            : Power.ChangeToScientificNotation((decimal)Convert.ToDouble(currentInput))))
                            : (string.IsNullOrEmpty(currentInput) ? "0" : currentInput));
                    }
                    else
                    {
                        if (currentstring == "" && input.Key != ConsoleKey.Backspace)
                        {
                            continue;
                        }
                        string temp = currentstring;

                        if (IsOperand(temp) && (!functionKeyPressed) && firstOccuranceOfOperator == false)
                        {
                            // 5+2=7, 8 previous result clear if we enter a operand
                            if (IsNextInput == true)
                            {
                                currentInput = "";
                                currentInput += temp;
                                IsNextInput = false;
                            }
                            else
                            {
                                currentInput += temp;
                            }
                        }
                        if (IsOperand(temp) && functionKeyPressed)
                        {
                            currentInput = "";
                            currentInput += temp;
                            functionKeyPressed = false;
                            if (firstOccuranceOfOperator)
                                showFunctions.Remove(thatIndex, showFunctions.Length - thatIndex);
                        }
                        if (IsOperand(temp) && (!functionKeyPressed) && firstOccuranceOfOperator)
                        {
                            currentInput = "";
                            currentInput += temp;
                            firstOccuranceOfOperator = false;
                        }
                        if (IsOperator(temp) && !firstOccuranceOfOperator)
                        {
                            infunctionOnce = 0;
                            toCheckOpenBracket = false;
                            firstOccuranceOfOperator = true;
                            if (currentInput[0] == '-')
                            {
                                outputString.Append(String.Format("(" + currentInput + ")"));
                                outputString.Append(temp);
                                if (functionKeyPressed)
                                {
                                    showFunctions.Append(temp);

                                }
                                else if (!functionKeyPressed)
                                {
                                    showFunctions.Append(String.Format("(" + currentInput + ")"));
                                    showFunctions.Append(temp);
                                }

                            }
                            else
                            {
                                // printing third line i.e. output after entering input and '='
                                if (outputString.Length > 0 && outputString[outputString.Length - 1] == ')')
                                {
                                    outputString.Append(temp);
                                    outputString.Append(currentInput);
                                    outputString.Append(temp);
                                    showFunctions.Append(temp);
                                    showFunctions.Append(currentInput);
                                    showFunctions.Append(temp);
                                }
                                else
                                {
                                    outputString.Append(currentInput);
                                    outputString.Append(temp);
                                    if (functionKeyPressed)
                                    {
                                        if (showFunctions[showFunctions.Length - 1] == '(')
                                        {
                                            showFunctions.Append(currentInput);
                                        }
                                        showFunctions.Append(temp);
                                    }
                                    else if (!functionKeyPressed)
                                    {
                                        showFunctions.Append(currentInput);
                                        showFunctions.Append(temp);
                                    }

                                }
                            }
                            functionKeyPressed = false;
                        }
                        if (IsOperator(temp) && functionKeyPressed && firstOccuranceOfOperator)
                        {
                            if (currentInput[0] == '-')
                            {
                                outputString.Append("(" + currentInput + ")");
                            }
                            else
                                outputString.Append(currentInput);
                            outputString.Append(temp);
                            if (showFunctions[showFunctions.Length - 1] == '(')
                            {
                                showFunctions.Append(currentInput);
                            }
                            showFunctions.Append(temp);
                            functionKeyPressed = false;
                            infunctionOnce = 0;
                            toCheckOpenBracket = false;
                            firstOccuranceOfOperator = false;
                        }
                        Console.Clear();
                       // Key_Mapping.ShowKeysWithFunctions();

                        Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                        Console.WriteLine(outputString.ToString());
                        Console.WriteLine(showFunctions.ToString());
                    }

                    if (currentInput.Length > 0 && operatorAfterOperator == false)
                    {
                        Console.WriteLine(IsScientificNotation
                            ? (string.IsNullOrEmpty(currentInput) ? Power.ChangeToScientificNotation(0)
                            : (Decimal.TryParse(currentInput, out OutputConverted) ? Power.ChangeToScientificNotation(OutputConverted)
                            : Power.ChangeToScientificNotation((decimal)Convert.ToDouble(currentInput))))
                            : (string.IsNullOrEmpty(currentInput) ? "0" : currentInput));
                    }

                    if (input.Key == ConsoleKey.Backspace)
                    {
                        StringBuilder OperandAndOperatorsCount = new StringBuilder(currentInput);
                        if (currentInput.Length > 0)
                        {
                            OperandAndOperatorsCount.Remove(OperandAndOperatorsCount.Length - 1, 1);
                            currentInput = OperandAndOperatorsCount.ToString();
                        }
                        Console.Clear();
                     //   Key_Mapping.ShowKeysWithFunctions();

                        Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                        Console.WriteLine(outputString.ToString());
                        Console.WriteLine(showFunctions.ToString());
                        Console.WriteLine(IsScientificNotation
                            ? (string.IsNullOrEmpty(currentInput) ? Power.ChangeToScientificNotation(0)
                            : (Decimal.TryParse(currentInput, out OutputConverted) ? Power.ChangeToScientificNotation(OutputConverted)
                            : Power.ChangeToScientificNotation((decimal)Convert.ToDouble(currentInput))))
                            : (string.IsNullOrEmpty(currentInput) ? "0" : currentInput));
                    }
                }
                while ((input.Key != ConsoleKey.Enter) && (input.Key != ConsoleKey.OemPlus));
                if (outputString.Length > 0 && IsOperator(outputString[outputString.Length - 1].ToString()))
                {
                    if (currentInput.Length > 0)
                    {
                        if (currentInput[0] == '-')
                        {
                            outputString.Append(String.Format("(" + currentInput + ")"));
                            if (!functionKeyPressed)
                                showFunctions.Append(String.Format("(" + currentInput + ")"));
                        }
                        else
                        {
                            outputString.Append(currentInput);
                            if (!functionKeyPressed)
                                showFunctions.Append(currentInput);
                        }
                    }
                    else
                    {
                        outputString.Append("0");
                        if (!functionKeyPressed)
                            showFunctions.Append("0");
                    }

                }
                if (outputString.Length == 0)
                {
                    if (currentInput.Length > 0)
                    {
                        outputString.Append(currentInput);
                        if (!functionKeyPressed)
                            showFunctions.Append(currentInput);
                    }
                    else
                    {
                        outputString.Append("0");
                        if (!functionKeyPressed)
                            showFunctions.Append("0");
                    }
                }
                for (int i = 0; i < OpenBracketCount; i++)
                {
                    if (showFunctions[i] == '(' && showFunctions[showFunctions.Length - 1] != ')')
                    {
                        showFunctions.Append(currentInput == "" ? "0" : currentInput);
                    }
                    showFunctions.Append(")");
                }
                for (int i = 0; i < ToDisplayOpenBracketCount; i++)
                {
                    if (outputString[i] == '(' && outputString[outputString.Length - 1] != ')')
                    {
                        outputString.Append(currentInput == "" ? "0" : currentInput);
                    }
                    outputString.Append(")");
                }
                Console.Clear();
             //   Key_Mapping.ShowKeysWithFunctions();

                if (outputString.Length > 0)
                {
                    try
                    {
                        result = ArithmeticExpression.EvaluateExpression(outputString.ToString());
                        Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                        Console.WriteLine(outputString.ToString() + "=");
                        Console.WriteLine(showFunctions.ToString() + "=");
                        if (IsScientificNotation)
                        {
                            Console.WriteLine(Power.ChangeToScientificNotation(result));
                        }
                        else
                        {
                            Console.WriteLine(result);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                        Console.WriteLine(outputString.ToString() + "=");
                        Console.WriteLine(showFunctions.ToString() + "=");
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    Console.WriteLine(angleMeasureMode + "\t" + ScientificNotationStatus + "\t" + String.Format(checkMemory ? "M" : ""));
                    Console.WriteLine(outputString.ToString());
                    Console.WriteLine(showFunctions.ToString());
                    Console.WriteLine(IsScientificNotation
                        ? (string.IsNullOrEmpty(currentInput) ? Power.ChangeToScientificNotation(0)
                        : (Decimal.TryParse(currentInput, out OutputConverted) ? Power.ChangeToScientificNotation(OutputConverted)
                        : Power.ChangeToScientificNotation((decimal)Convert.ToDouble(currentInput))))
                        : (string.IsNullOrEmpty(currentInput) ? "0" : currentInput));
                }
                outputString.Clear();
                showFunctions.Clear();
                currentInput = result.ToString();
                functionKeyPressed = false;
                firstOccuranceOfOperator = false;
                IsNextInput = true;
                infunctionOnce = 0;
                OpenBracketCount = 0;
                ToDisplayOpenBracketCount = 0;
            }
        }
        static string Value(ConsoleKeyInfo ckinfoKey)
        {
            switch (ckinfoKey.Key)
            {
                case ConsoleKey.Z:                               // Anglemode toggle
                    angleModeTapCount++;
                    if (angleModeTapCount == 0)
                    {
                        angleMeasureMode = "DEG";
                    }
                    else if (angleModeTapCount == 1)
                    {
                        angleMeasureMode = "RAD";
                    }
                    else if (angleModeTapCount == 2)
                    {
                        angleMeasureMode = "GRAD";
                    }
                    else if (angleModeTapCount == 3)
                    {
                        angleModeTapCount = 0;
                        angleMeasureMode = "DEG";
                    }
                    return "";
                case ConsoleKey.V:                            // Scientific Notation
                    ScientificNotationCount++;
                    if (ScientificNotationCount == 0)
                    {
                        ScientificNotationStatus = "F-E";
                        IsScientificNotation = false;
                    }
                    else if (ScientificNotationCount == 1)
                    {
                        ScientificNotationStatus = "E-F";
                        IsScientificNotation = true;
                    }
                    else if (ScientificNotationCount == 2)
                    {
                        ScientificNotationCount = 0;
                        IsScientificNotation = false;
                        ScientificNotationStatus = "F-E";
                    }
                    return "";
                case ConsoleKey.Delete:                     // to clear all current input
                    {
                        if (currentInput.Length > 0)
                        {
                            currentInput = "";
                        }
                        else if (currentInput.Length == 0 || currentInput[0] == '0')
                        {
                            outputString.Clear();
                        }
                        return "";
                    }
                case ConsoleKey.D0:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        if (toCheckOpenBracket)
                        {
                            if (currentInput.Length > 0)
                            {
                                outputString.Append(currentInput + ")");
                                showFunctions.Append(currentInput + ")");
                            }
                            else
                            {
                                outputString.Append("0)");
                                showFunctions.Append("0)");

                            }
                            toCheckOpenBracket = false;
                            ToDisplayOpenBracketCount--;
                            OpenBracketCount--;
                        }
                        else if (!toCheckOpenBracket)
                        {
                            if (OpenBracketCount > 0)
                            {
                                showFunctions.Append(')');
                                OpenBracketCount--;
                            }
                            if (ToDisplayOpenBracketCount > 0)
                            {
                                outputString.Append(')');
                                ToDisplayOpenBracketCount--;
                            }
                        }
                        return "";
                    }
                    else
                    {
                        return "0";
                    }
                case ConsoleKey.D1: return "1";
                case ConsoleKey.D2: return "2";
                case ConsoleKey.D3: return "3";
                case ConsoleKey.D4: return "4";
                case ConsoleKey.D5: return "5";
                case ConsoleKey.D6:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "^";
                    }
                    else
                    {
                        return "6";
                    }
                case ConsoleKey.D7: return "7";
                case ConsoleKey.D8:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "*";
                    }
                    else
                    {
                        return "8";
                    }
                case ConsoleKey.D9:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        functionKeyPressed = true;
                        if (!toCheckOpenBracket)
                        {
                            toCheckOpenBracket = true;
                            if (outputString.Length > 0)
                            {
                                if (IsOperator(outputString[outputString.Length - 1].ToString()))
                                {
                                    outputString.Append("(");
                                    showFunctions.Append("(");
                                    ToDisplayOpenBracketCount++;
                                    OpenBracketCount++;
                                }
                                else
                                {
                                    if (currentInput.Length > 0)
                                    {
                                        outputString.Append(currentInput);
                                        outputString.Append("*(");
                                        showFunctions.Append("*(");
                                        OpenBracketCount++;
                                        ToDisplayOpenBracketCount++;
                                    }
                                    else
                                    {
                                        showFunctions.Append("(");
                                        OpenBracketCount++;
                                    }
                                }
                            }
                            else
                            {
                                if (currentInput.Length > 0)
                                {
                                    outputString.Append(currentInput + "*(");
                                    showFunctions.Append(currentInput + "*(");
                                    ToDisplayOpenBracketCount++;
                                    OpenBracketCount++;
                                }
                                else
                                {
                                    outputString.Append("(");
                                    showFunctions.Append("(");
                                    ToDisplayOpenBracketCount++;
                                    OpenBracketCount++;
                                }
                            }
                        }
                        else if (toCheckOpenBracket)
                        {
                            if (outputString.Length > 0)
                            {
                                showFunctions.Append("(");
                                OpenBracketCount++;
                            }
                            else
                            {
                                if (currentInput.Length > 0)
                                {
                                    showFunctions.Append(currentInput + "(");
                                    OpenBracketCount++;
                                }
                                else
                                {
                                    outputString.Append("(");
                                    showFunctions.Append("(");
                                    ToDisplayOpenBracketCount++;
                                    OpenBracketCount++;
                                }
                            }
                        }
                        return "";
                    }
                    else
                    {
                        return "9";
                    }
                case ConsoleKey.NumPad0: return "0";
                case ConsoleKey.NumPad1: return "1";
                case ConsoleKey.NumPad2: return "2";
                case ConsoleKey.NumPad3: return "3";
                case ConsoleKey.NumPad4: return "4";
                case ConsoleKey.NumPad5: return "5";
                case ConsoleKey.NumPad6: return "6";
                case ConsoleKey.NumPad7: return "7";
                case ConsoleKey.NumPad8: return "8";
                case ConsoleKey.NumPad9: return "9";
                case ConsoleKey.D:                                                      // Degree Conversion
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        currentInput = Power.ConvertToDMS(newNumber).ToString();
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        currentInput = Power.DMSToDegree(newNumber).ToString();
                        return "";
                    }
                case ConsoleKey.M:                                                                // Memory Functions
                    if (currentInput == "")
                    {
                        currentInput = "0";
                    }
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)   //MS
                    {
                        memory = Convert.ToDouble(currentInput);
                        checkMemory = true;
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0) //M+
                    {
                        memory += Convert.ToDouble(currentInput);
                        checkMemory = true;
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)  //M-
                    {
                        memory -= Convert.ToDouble(currentInput);
                        checkMemory = true;
                        return "";
                    }
                    else                                                               //Memory Recall Function
                    {
                        if (checkMemory == false)
                        {
                            return "";
                        }
                        else
                        {
                            currentInput = memory.ToString();
                        }
                        return "";
                    }
                case ConsoleKey.B:                                                    // Memory Clear Function
                    memory = 0;
                    checkMemory = false;
                    return "";
                    // Trigno Functions
                case ConsoleKey.S:                                                      // Sine
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"sinh({enteredAngle})");
                        double tempValue = Trignometric.SineHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else
                        {
                            currentInput = tempValue.ToString();
                        }
                        enteredAngle = $"sinh({enteredAngle})";
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"sin{'\u207B'}{'\u00B9'}({enteredAngle})");
                        double tempValue = Trignometric.SineInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"sin^(-1)({enteredAngle})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"sin({enteredAngle})");
                        double tempValue = Trignometric.Sine(newNumber, angleMeasureMode);

                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString();
                        }
                        enteredAngle = $"sin({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.C:                                                       // Cosine
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Cosh({enteredAngle})");
                        double tempValue = Trignometric.CosineHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Cosh({enteredAngle})";
                        return "";

                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Cos^(-1)({enteredAngle})");
                        double tempValue = Trignometric.CosineInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Cos^(-1)({enteredAngle})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Cos({enteredAngle})");
                        double tempValue = Trignometric.Cosine(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Cos({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.T:                                                                // Tangent
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"tanh({enteredAngle})");
                        double tempValue = Trignometric.TangentHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"tanh({enteredAngle})";
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"tan^(-1)({enteredAngle})");
                        double tempValue = Trignometric.TangentInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else
                        {
                            currentInput = tempValue.ToString();
                        }
                        enteredAngle = $"tan^(-1)({enteredAngle})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"tan({enteredAngle})");
                        double tempValue = Trignometric.Tangent(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString();
                        }
                        enteredAngle = $"tan({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.O:                                                                    // Cot
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Coth({enteredAngle})");
                        double tempValue = Trignometric.CotHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Coth({enteredAngle})";
                        return "";
                    }

                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Cot^(-1)({enteredAngle})");
                        double tempValue = Trignometric.CotInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Cot^(-1)({enteredAngle})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Cot({enteredAngle})");
                        double tempValue = Trignometric.Cot(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Cot({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.N:                                                              // Secant
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Sech({enteredAngle})");
                        double tempValue = Trignometric.SecHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput  = tempValue.ToString(); 
                        }
                        enteredAngle = $"Sech({enteredAngle})";
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Sec^(-1)({enteredAngle})");
                        double tempValue = Trignometric.SecInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Sec^(-1)({enteredAngle})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Sec({enteredAngle})");
                        double tempValue = Trignometric.Sec(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Sec({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.Q:                                                                 // Cosec
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Csch({enteredAngle})");
                        double tempValue = Trignometric.CosecHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Csch({enteredAngle})";
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Csc^(-1)({enteredAngle})");
                        double tempValue = Trignometric.CosecInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Csc^(-1)({enteredAngle})";
                        return "";

                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"{outputString}Csc({enteredAngle})");
                        double tempValue = Trignometric.Cosec(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"Csc({enteredAngle})";
                        return "";
                    }
                // Log Functions
                case ConsoleKey.L:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        FormatInput();
                        showFunctions.Append($"log10({enteredAngle})");
                        Double.TryParse(currentInput, out double newNumber);
                        double tempValue = Power.LogBase10(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"log10({enteredAngle})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        showFunctions.Append($"ln({enteredAngle})");
                        Double.TryParse(currentInput, out double newNumber);
                        double tempValue = Power.NaturalLog(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        enteredAngle = $"ln({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.P:                                            // pi value
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        // Formating();
                        string tempValue = Math.PI.ToString();
                        currentInput = tempValue;
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)               //2^(x)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"2^({enteredAngle})");
                        string ans = Power.Exponentiation(2, newNumber).ToString();
                        currentInput = ans;
                        enteredAngle = $"2^({enteredAngle})";
                        return "";
                    }
                    else if ((ckinfoKey.Modifiers & ConsoleModifiers.Control) != 0)                  //10^(x)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"10^({enteredAngle})");
                        string ans = Power.Exponentiation(10, newNumber).ToString();
                        currentInput = ans;
                        enteredAngle = $"10^({enteredAngle})";
                        return "";
                    }
                    else                                                                   //Power
                    {
                        return "^";
                    }
                case ConsoleKey.J:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)             // cube root
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"√({enteredAngle})");
                        try
                        {
                            double tempValue = Power.CubeRoot(newNumber);
                            currentInput = tempValue.ToString();
                        }
                        catch (Exception e)
                        {
                            currentInput = e.Message;
                            outputString.Clear();
                        }
                        enteredAngle = $"√({enteredAngle})";
                        return "";
                    }

                    else                            // sqr root
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"√({enteredAngle})");
                        try
                        {
                            double tempValue = Power.SquareRoot(newNumber);
                            currentInput = tempValue.ToString();
                        }
                        catch (Exception e)
                        {
                            currentInput = e.Message;
                            outputString.Clear();
                        }
                        enteredAngle = $"√({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.R:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)                    //cube function
                    {
                        FormatInput();
                        showFunctions.Append($"cube({enteredAngle})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = Power.Exponentiation(newNumber, 3).ToString();
                        currentInput = ans;
                        enteredAngle = $"cube({enteredAngle})";
                        return "";
                    }

                    else                            // square function
                    {
                        FormatInput();
                        showFunctions.Append($"cube({currentInput})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = Power.Exponentiation(newNumber, 2).ToString();
                        currentInput = ans;
                        enteredAngle = $"cube({currentInput})";
                        return "";
                    }
                case ConsoleKey.G:
                    {
                        double random = Power.GenerateRandom();
                        currentInput = random.ToString();
                        return "";
                    }
                    // Floor value
                case ConsoleKey.Oem4:                                
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Floring({enteredAngle})");
                        string ans = Power.FloorValue(newNumber).ToString();
                        currentInput = ans;
                        enteredAngle = $"Floring({enteredAngle})";
                        return "";
                    }
                    // Ceiling value
                case ConsoleKey.Oem6:
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"Ceiling({enteredAngle})");
                        string ans = Power.CeilingValue(newNumber).ToString();
                        currentInput = ans;
                        enteredAngle = $"Ceiling({enteredAngle})";
                        return "";
                    }
                    // Factorial
                case ConsoleKey.F:
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"fact({enteredAngle})");
                        try
                        {
                            string ans = Power.CalculateFactorial(newNumber).ToString();
                            currentInput = ans;
                        }
                        catch (Exception e)
                        {
                            currentInput = e.Message;
                            outputString.Clear();
                        }
                        enteredAngle = $"fact({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.Backspace: return "";
                case ConsoleKey.Enter: return "";
                case ConsoleKey.Add: return "+";
                case ConsoleKey.Subtract: return "-";
                case ConsoleKey.Multiply: return "*";
                case ConsoleKey.Divide: return "/";
                case ConsoleKey.Oem2: return "/";
                case ConsoleKey.OemPeriod: return ".";
                case ConsoleKey.Decimal: return ".";
                    // absolute value
                case ConsoleKey.A:
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"abs({enteredAngle})");
                        string ans = (Power.AbsoluteValue(newNumber)).ToString();
                        currentInput = ans;
                        enteredAngle = $"abs({enteredAngle})";
                        return "";
                    }
                case ConsoleKey.E:
                    if ((ckinfoKey.Modifiers & ConsoleModifiers.Shift) != 0)            //e value
                    {
                        currentInput = Math.E.ToString();
                        enteredAngle = $"e^({currentInput})";
                        return Math.E.ToString();
                    }
                    else                                                            //e^x
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        showFunctions.Append($"e^({currentInput})");
                        string ans = Power.EPowerx(newNumber).ToString();
                        currentInput = ans;
                        enteredAngle = $"e^({currentInput})";
                        return "";
                    }
                case ConsoleKey.Escape:
                    Environment.Exit(0);
                    return "";
                    // negate value
                case ConsoleKey.OemMinus:
                    FormatInput();
                    showFunctions.Append($"negate({enteredAngle})");
                    enteredAngle = $"negate({enteredAngle})";
                    if (currentInput[0] == '-')
                    {
                        currentInput = currentInput.Substring(1);
                    }
                    else
                        currentInput = '-' + currentInput.Substring(0);

                    return "";
                default: return "";
            }
            // for function to delete input after append output to input
            void FormatInput()
            {
                functionKeyPressed = true;
                if (infunctionOnce == 0)
                {
                    enteredAngle = currentInput;
                    thatIndex = showFunctions.Length;
                }
                Console.Clear();
             //   Key_Mapping.ShowKeysWithFunctions();

                if (showFunctions.Length - enteredAngle.Length >= 0 && infunctionOnce != 0)
                    showFunctions.Remove(showFunctions.Length - enteredAngle.Length, enteredAngle.Length);
                infunctionOnce++;
            }
        }
        static bool IsOperator(string x)
        {
            return x == "+" || x == "-" || x == "*" || x == "/" || x == "^";
        }
        static bool IsOperand(string x)
        {
            return x == "0" || x == "1" || x == "2" || x == "3" || x == "4" || x == "5" || x == "6" || x == "7" || x == "8" || x == "9" || x == ".";
        }
    }
}




































/*using ArithmeticOperations;
using PowerOperations;
using System;
using System.Text;
using TrignometricOperations;

namespace ScientificCalculator
{
    internal class Program
    {
        static bool isNextInput = false;
        static bool memoryCheck = false;
        static bool ScientificNotation = false;
        static bool Isfunction = false;

        static int angleModeTapCount = 0;
        static int outputCountTap = 0;
        static double memory = 0;

        static StringBuilder outputString = new StringBuilder();
        static StringBuilder ShowFunctions = new StringBuilder();

        static string currentInput = "";
        static string angleMeasureMode = "DEG";
        static string outputStatus = "F-E";
        static string currenttrigno = "";
        static string CheckNumber;           // thatNumber


        static void Main()
        {
            Console.Title = "Welcome To Scientific Calculator ";
            ConsoleKeyInfo input;
            Console.CursorVisible = false;
            bool operatorAfterOperator;
            double result = 0;
            Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
            Console.WriteLine(ShowFunctions.ToString());
            Console.TreatControlCAsInput = true;

            while (true)
            {
                do
                {
                    input = Console.ReadKey(true);
                    operatorAfterOperator = false;
                    Isfunction = false;
                    Console.WriteLine(ShowFunctions.ToString());
                    string currentstring = Value(input);

                    // for multiple sequential operator
                    if (IsOperator(currentstring) && outputString.Length != 0 && IsOperator(outputString[outputString.Length - 1].ToString()))
                    {
                        operatorAfterOperator = true;
                        ShowFunctions.Remove(ShowFunctions.Length - 1, 1);
                        outputString.Remove(outputString.Length - 1, 1);
                        outputString.Append(currentstring);
                        Console.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.Write(outputString.ToString());
                    }
                    // if starting input is operator , append 0 in output
                    else if (IsOperator(currentstring) && outputString.Length == 0)
                    {
                        operatorAfterOperator = true;
                        outputString.Append("0");
                        outputString.Append(currentstring);
                        Console.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.Write(outputString.ToString());
                    }
                    else
                    {
                        if (currentstring == "" && input.Key != ConsoleKey.Backspace)
                        {
                            continue;
                        }
                        string temp = currentstring;
                        outputString.Append(temp);
                        if (temp == "(NaN)")
                        {
                            Console.Clear();
                            outputString.Clear();
                            Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                            Console.WriteLine("Invalid Input");
                        }
                        if (IsOperand(temp) && isNextInput == false)
                        {
                            currentInput += temp;
                        }
                        else if (IsOperator(temp))
                        {
                            currentInput = "";
                            currenttrigno = "";
                        }
                        else
                        {

                        }
                    }
                    // 5+2=7, 8 previous result clear if we enter a operand
                    if (isNextInput == true)
                    {
                        if (outputString[outputString.Length - 1] >= '0' && outputString[outputString.Length - 1] <= '9' && Isfunction == false)
                        {
                            Console.Clear();
                            outputString.Clear();
                            Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                            outputString.Append(currentstring);
                            currentInput = currentstring;
                        }
                        isNextInput = false;
                    }
                    // printing third line i.e. output after entering input and '='
                    if (outputString.Length > 0 && operatorAfterOperator == false && Isfunction == false)
                    {

                        Console.Write(currentstring);

                        int originalLeft = Console.CursorLeft;
                        int originalTop = Console.CursorTop;
                        Console.SetCursorPosition(0, 2);

                        Console.WriteLine(String.Format(currentInput == "" ? "0" : currentInput));
                        Console.SetCursorPosition(originalLeft, originalTop);

                    }

                    if (input.Key == ConsoleKey.Backspace)
                    {
                        if (outputString.Length > 0)
                        {
                            outputString.Remove(outputString.Length - 1, 1);
                        }
                        Console.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.Write(outputString.ToString());
                    }
                } while ((input.Key != ConsoleKey.Enter) && (input.Key != ConsoleKey.OemPlus));

                Console.Clear();
                if (outputString.Length > 0)
                {
                    try
                    {
                        result = (double)ArithmeticExpression.EvaluateExpression(outputString.ToString());
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.WriteLine(outputString.ToString() + "=");
                        if (ScientificNotation)
                        {
                            Console.Write(Power.ChangeToScientificNotation(Convert.ToDecimal(result)));
                        }
                        else
                        {
                            Console.Write(result);
                        }
                    }
                    catch (DivideByZeroException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    outputString.Append(0);
                    Console.WriteLine(outputString.ToString() + "=");
                    Console.Write(0);
                }
                outputString.Clear();
                outputString.Append(result);
                currentInput = result.ToString();
                isNextInput = true;
            }
        }

        static string Value(ConsoleKeyInfo cKeyInfo)
        {
            switch (cKeyInfo.Key)
            {
                case ConsoleKey.D:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}dms({currentInput})");
                        string ans = Power.ConvertToDMS(newNumber).ToString();
                        return ans;
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}degrees({currentInput})");
                        string ans = Power.DMSToDegree(newNumber).ToString();
                        return ans;
                    }
                // Memory Functions
                case ConsoleKey.M:
                    if (currentInput == "")
                    {
                        currentInput = "0";
                    }
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)   //MS
                    {
                        memory = Convert.ToDouble(currentInput);
                        memoryCheck = true;
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0) //M+
                    {
                        memory += Convert.ToDouble(currentInput);
                        memoryCheck = true;
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)  //M-
                    {
                        memory -= Convert.ToDouble(currentInput);
                        memoryCheck = true;
                        return "";
                    }
                    else                                              //MR
                    {
                        if (memoryCheck == false)
                        {
                            return "";
                        }
                        else
                        {
                            currentInput = memory.ToString();
                        }
                        return "";
                    }
                case ConsoleKey.B:  //MC
                    memory = 0;
                    memoryCheck = false;
                    return "";
                case ConsoleKey.S:                                                // Trigno Functions
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}sinh({CheckNumber})");
                        double tempValue = Trignometric.SineHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else
                        {
                            currentInput = tempValue.ToString();
                        }
                        CheckNumber = $"sinh({CheckNumber})";
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"sin{'\u207B'}{'\u00B9'}({CheckNumber})");
                        double tempValue = Trignometric.SineInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"sin^(-1)({CheckNumber})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"sin({CheckNumber})");
                        double tempValue = Trignometric.Sine(newNumber, angleMeasureMode);

                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else
                        { 
                            currentInput = tempValue.ToString(); 
                        }

                        CheckNumber = $"sin({CheckNumber})";
                        return "";
                    }
                                                
                case ConsoleKey.C:                        // Cosine
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Cosh({CheckNumber})");
                        double tempValue = Trignometric.CosineHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else { currentInput = tempValue.ToString(); }
                        CheckNumber = $"Cosh({CheckNumber})";
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Cos^(-1)({CheckNumber})");
                        double tempValue = Trignometric.CosineInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString();
                        }
                        CheckNumber = $"Cos^(-1)({CheckNumber})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Cos({CheckNumber})");
                        double tempValue = Trignometric.Cosine(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"Cos({CheckNumber})";
                        return "";
                    }
                case ConsoleKey.T:                                                             // Tangent
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"tanh({CheckNumber})");
                        double tempValue = Trignometric.TangentHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"tanh({CheckNumber})";
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"tan^(-1)({CheckNumber})");
                        double tempValue = Trignometric.TangentInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"tan^(-1)({CheckNumber})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"tan({CheckNumber})");
                        double tempValue = Trignometric.Tangent(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"tan({CheckNumber})";
                        return "";
                    }
                case ConsoleKey.O:                 // Cot
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Coth({CheckNumber})");
                        double tempValue = Trignometric.CotHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else { currentInput = tempValue.ToString(); }
                        CheckNumber = $"Coth({CheckNumber})";
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Cot^(-1)({CheckNumber})");
                        double tempValue = Trignometric.CotInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"Cot^(-1)({CheckNumber})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Cot({CheckNumber})");
                        double tempValue = Trignometric.Cot(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"Cot({CheckNumber})";
                        return "";
                    }
                case ConsoleKey.N:                     // Sec
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Sech({CheckNumber})");
                        double tempValue = Trignometric.SecHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"Sech({CheckNumber})";
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Sec^(-1)({CheckNumber})");
                        double tempValue = Trignometric.SecInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"Sec^(-1)({CheckNumber})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Sec({CheckNumber})");
                        double tempValue = Trignometric.Sec(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"Sec({CheckNumber})";
                        return "";
                    }
                case ConsoleKey.Q:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Csch({CheckNumber})");
                        double tempValue = Trignometric.CosecHyp(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"Csch({CheckNumber})";
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Csc^(-1)({CheckNumber})");
                        double tempValue = Trignometric.CosecInverse(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else { currentInput = tempValue.ToString(); }
                        CheckNumber = $"Csc^(-1)({CheckNumber})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"Csc({CheckNumber})");
                        double tempValue = Trignometric.Cosec(newNumber, angleMeasureMode);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString();
                        }
                        CheckNumber = $"Csc({CheckNumber})";
                        return "";
                    }
                case ConsoleKey.L:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        FormatInput();
                        ShowFunctions.Append($"log10({CheckNumber})");
                        Double.TryParse(currentInput, out double newNumber);
                        double tempValue = Power.LogBase10(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else 
                        { 
                            currentInput = tempValue.ToString(); 
                        }
                        CheckNumber = $"log10({CheckNumber})";
                        return "";
                    }
                    else
                    {
                        FormatInput();
                        ShowFunctions.Append($"ln({CheckNumber})");
                        Double.TryParse(currentInput, out double newNumber);
                        double tempValue = Power.NaturalLog(newNumber);
                        if (Double.IsNaN(tempValue) || Double.IsInfinity(tempValue))
                        {
                            outputString.Clear();
                            if (Double.IsNaN(tempValue))
                            {
                                currentInput = "Invailid input";
                            }
                            else
                            {
                                currentInput = "Cannot divide by zero";
                            }
                        }
                        else { currentInput = tempValue.ToString(); }
                        CheckNumber = $"ln({CheckNumber})";
                        return "";
                    }              
                case ConsoleKey.A:               // to find absolute value
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"abs({CheckNumber})");
                        string ans = (Power.AbsoluteValue(newNumber)).ToString();
                        currentInput = ans;
                        CheckNumber = $"abs({currentInput})";
                        return "";
                    }
                case ConsoleKey.P:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)         // PI value
                    {
                        string tempValue = Math.PI.ToString();
                        currentInput = tempValue;
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)      //2^(x) 
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"2^({CheckNumber})");
                        string ans = Power.Exponentiation(2, newNumber).ToString();
                        currentInput = ans;
                        CheckNumber = $"2^({currentInput})";
                        return "";
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Control) != 0)        //10^(x)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"10^({CheckNumber})");
                        string ans = Power.Exponentiation(10, newNumber).ToString();
                        currentInput = ans;
                        CheckNumber = $"10^({currentInput})";
                        return "";
                    }
                    else
                    {
                        return "^";
                    }
                case ConsoleKey.E:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)      // e value
                    {
                        currentInput = Math.E.ToString();
                        CheckNumber = $"e^({currentInput})";
                        return Math.E.ToString();
                    }

                    else                                                           // e ki power x
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"e^({CheckNumber})");
                        string ans = Power.EPowerx(newNumber).ToString();
                        currentInput = ans;
                        CheckNumber = $"e^({currentInput})";
                        return "";
                    }
                case ConsoleKey.V:
                    outputCountTap++;
                    if (outputCountTap == 0)
                    {
                        outputStatus = "F-E";
                        ScientificNotation = false;
                    }
                    else if (outputCountTap == 1)
                    {
                        outputStatus = "E-F";
                        ScientificNotation = true;
                    }
                    else if (outputCountTap == 2)
                    {
                        outputCountTap = 0;
                        ScientificNotation = false;
                        outputStatus = "F-E";
                    }
                    return "";
                case ConsoleKey.Z:
                    angleModeTapCount++;
                    if (angleModeTapCount == 0)
                    {
                        angleMeasureMode = "DEG";
                    }
                    else if (angleModeTapCount == 1)
                    {
                        angleMeasureMode = "RAD";
                    }
                    else if (angleModeTapCount == 2)
                    {
                        angleMeasureMode = "GRAD";
                    }
                    else if (angleModeTapCount == 3)
                    {
                        angleModeTapCount = 0;
                        angleMeasureMode = "DEG";
                    }
                    return "";
                case ConsoleKey.R:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)        // cube
                    {
                        FormatInput();
                        ShowFunctions.Append($"cube({CheckNumber})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = Power.Exponentiation(newNumber, 3).ToString();
                        currentInput = ans;
                        CheckNumber = $"cube({currentInput})";
                        return "";
                    }     
                    else
                    {
                        FormatInput();
                        ShowFunctions.Append($"cube({CheckNumber})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = Power.Exponentiation(newNumber, 2).ToString();
                        currentInput = ans;
                        CheckNumber = $"cube({currentInput})";
                        return "";
                    }
                case ConsoleKey.J:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Alt) != 0)          // to find square root
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}√({newNumber})");
                        string ans = Power.SquareRoot(newNumber).ToString();
                        return ans;
                    }
                    else if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)     // to find cube root
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}√({newNumber})");
                        string ans = Power.CubeRoot(newNumber).ToString();
                        return ans;
                    }
                    else
                    {
                        return "";
                    }
                case ConsoleKey.G:         // to generate random value of any number (rand)
                    {
                        FormatInput();
                        double random = Power.GenerateRandom();
                        Console.Write($"{random}");
                        return random.ToString();
                    }         
                case ConsoleKey.Oem4:       // to print floor value of any number
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}floor({currentInput})");
                        string ans = Power.FloorValue(newNumber).ToString();
                        return ans;
                    }
                case ConsoleKey.Oem6:       // to print ceiling value of any number
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Ceiling({currentInput})");
                        string ans = Power.CeilingValue(newNumber).ToString();
                        return ans;
                    }
                case ConsoleKey.F:                    // to find factorial 
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        ShowFunctions.Append($"fact({CheckNumber})");
                        try
                        {
                            string ans = Power.CalculateFactorial(newNumber).ToString();
                            currentInput  = ans;
                        }
                        catch (Exception e)
                        {
                            currentInput = e.Message;
                            outputString.Clear();
                        }
                        CheckNumber = $"fact({CheckNumber})";
                        return "";
                    }
                case ConsoleKey.OemMinus:            // negate
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}(-{currentInput})");
                        string ans = (-newNumber).ToString();
                        return ans;
                    }
                // Check for Esc key to terminate the program
                case ConsoleKey.Escape:
                    Environment.Exit(0);
                    return "";
                case ConsoleKey.Backspace: return "";
                case ConsoleKey.Add: return "+";
                case ConsoleKey.Subtract: return "-";
                case ConsoleKey.Multiply: return "*";
                case ConsoleKey.Divide: return "/";
                case ConsoleKey.Oem2: return "/";
                case ConsoleKey.OemPeriod: return ".";
                case ConsoleKey.D0:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return ")";
                    }
                    else
                    {
                        return "0";
                    }
                case ConsoleKey.D1: return "1";
                case ConsoleKey.D2: return "2";
                case ConsoleKey.D3: return "3";
                case ConsoleKey.D4: return "4";
                case ConsoleKey.D5: return "5";
                case ConsoleKey.D6:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "^";
                    }
                    else
                    {
                        return "6";
                    }
                case ConsoleKey.D7: return "7";
                case ConsoleKey.D8:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "*";
                    }
                    else
                    {
                        return "8";
                    }
                case ConsoleKey.D9:
                    if ((cKeyInfo.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "(";
                    }
                    else
                    {
                        return "9";
                    }
                case ConsoleKey.NumPad0: return "0";
                case ConsoleKey.NumPad1: return "1";
                case ConsoleKey.NumPad2: return "2";
                case ConsoleKey.NumPad3: return "3";
                case ConsoleKey.NumPad4: return "4";
                case ConsoleKey.NumPad5: return "5";
                case ConsoleKey.NumPad6: return "6";
                case ConsoleKey.NumPad7: return "7";
                case ConsoleKey.NumPad8: return "8";
                case ConsoleKey.NumPad9: return "9";
                case ConsoleKey.Delete:
                    {
                        Console.Clear();
                        outputString.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        return "";
                    }
                default: return "";
            }
        }
        static void FormatInput()
        {
            Isfunction = true;
            Console.Clear();
            Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
            outputString.Remove(outputString.Length - currentInput.Length, currentInput.Length);
        }
       

        static bool IsOperator(string x)
        {
            return x == "+" || x == "-" || x == "*" || x == "/" || x == "^";
        }
        static bool IsOperand(string x)
        {
            return x == "1" || x == "2" || x == "3" || x == "4" || x == "5" || x == "6" || x == "7" || x == "8" || x == "9" || x == "0" || x == ".";
        }

    }
}*/
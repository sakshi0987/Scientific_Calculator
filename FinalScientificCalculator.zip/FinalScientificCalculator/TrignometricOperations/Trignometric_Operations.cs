﻿using System;

namespace TrignometricOperations
{
    public class Trignometric
    {
        public static double ConvertAngleMode(double angle, String Status)
        {
            if (Status == "DEG")
            {
                if (angle >= 360)
                {
                    angle %= 360;
                }
                angle = (angle * Math.PI) / 180;
            }
            else if (Status == "GRAD")
            {
                if (angle >= 400)
                {
                    angle %= 400;
                }
                angle = (angle * Math.PI) / 200;
            }
            else
            {
                if (angle >= ((2 * 22) / 7))
                {
                    angle %= ((2 * 22) / 7);
                }
            }
            return angle;
        }

        public static double ConvertAngleValue(double angle, String Status)
        {
            if (Status == "DEG")
            {
                angle *= 180 / Math.PI;
            }
            else if (Status == "GRAD")
            {
                angle *= 200 / Math.PI;
            }
            return angle;
        }

        //Trignometric Function
        public static double Sine(double angle, String Status)
        {
            angle = ConvertAngleMode(angle, Status);
            return Math.Sin(angle);

        }

        public static double Cosine(double angle, String Status)
        {
            angle = ConvertAngleMode(angle, Status);
            return Math.Cos(angle);
        }

        public static double Tangent(double angle, String Status)
        {
            angle = ConvertAngleMode(angle, Status);
            return Math.Tan(angle);
        }

        public static double Cot(double angle, String Status)
        {
            return 1 / Tangent(angle, Status);
        }

        public static double Sec(double angle, String Status)
        {
            return 1 / Cosine(angle, Status);
        }

        public static double Cosec(double angle, String Status)
        {
            return 1 / Sine(angle, Status);
        }

        //Inverse Trignometric Function
        public static double SineInverse(double angle, String Status)
        {
            double temp= Math.Asin(angle);
            return ConvertAngleValue(temp , Status); 
            
        }

        public static double CosineInverse(double angle, String Status)
        {
            double temp = Math.Acos(angle);
            return ConvertAngleValue(temp, Status);
        }

        public static double TangentInverse(double angle, String Status)
        {
            double temp = Math.Atan(angle);
            return ConvertAngleValue(temp, Status);
        }

        public static double CotInverse(double angle, String Status)
        {
            return TangentInverse(1/angle, Status);
        }

        public static double SecInverse(double angle, String Status)
        {
            return CosineInverse(1/angle, Status);
        }

        public static double CosecInverse(double angle, String Status)
        {
            return  SineInverse(1/angle, Status);
        }

        //Hyperbolic Function
        public static double SineHyp(double angle)
        {
            return Math.Sinh(angle);
        }

        public static double CosineHyp(double angle)
        {
            return Math.Cosh(angle);
        }

        public static double TangentHyp(double angle)
        {
            return Math.Tanh(angle);
        }
        public static double CotHyp(double angle)
        {
            return 1 / TangentHyp(angle);
        }

        public static double SecHyp(double angle)
        {
            return 1 / CosineHyp(angle);
        }

        public static double CosecHyp(double angle)
        {
            return 1 / SineHyp(angle);
        }
    }
}

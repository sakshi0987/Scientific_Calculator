﻿using System;
namespace PowerOperations
{
    public class power
    {
        //Function
        public static double AbsoluteValue(double input)
        {
            return Math.Abs(input);
        }

        public static double FloorValue(double input)
        {
            return Math.Floor(input);
        }
        public static double CeilingValue(double input)
        {
            return Math.Ceiling(input);
        }

        public static double GenerateRandom()
        {
            return new Random().NextDouble();
        }



        public static double ConvertToDMS(double angle1)
        {
            int degrees = (int)Math.Floor(angle1);
            double minutes = (angle1 - degrees) * 60;
            int minutesInt = (int)Math.Floor(minutes);
            double seconds = (minutes - minutesInt) * 60;
            double result = degrees + minutesInt / 100.0 + seconds / 10000.0;
            return result;
        }
        public static double DMSToDegree(double angle1)
        {
            int degrees = (int)Math.Floor(angle1);
            double minutes = (angle1 - degrees);
            double result = degrees + (minutes / 60);
            return result;
        }
        public static string ChangeToScientificNotation(double number)
        {
            string scientificNotation = number.ToString("E");
            return scientificNotation;
        }
        //Power Functions
        public static double Exponentiation(double baseValue, double exponent)
        {
            return Math.Pow(baseValue, exponent);
        }

        public static double Root(double baseValue, double rootValue)
        {
            return Math.Pow(baseValue, 1.0 / rootValue);
        }

        public static double SquareRoot(double number)
        {
            if (number < 0)
            {
                throw new ArgumentException("Invalid input");
            }
            return Math.Sqrt(number);
        }

        public static double CubeRoot(double number)
        {
            if (number < 0)
            {
                throw new ArgumentException("Invalid input");
            }
            return Math.Pow(number, 1.0 / 3.0);
        }

        public static double LogBase10(double x)
        {
            return Math.Log10(x);
        }

        public static double NaturalLog(double x)
        {
            return Math.Log(x);
        }

        public static double Exponential(double x)
        {
            return Math.Exp(x);
        }

        public static double Factorial(double n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Invalid input");
            }

            if (n == 0 || n == 1)
            {
                return 1;
            }

            double result = 1;
            for (int i = 2; i <= n; i++)
            {
                result *= i;
            }

            return result;
        }


    }
}

﻿using System;
using ArithmeticOperations;
using PowerOperations;
using TrignometricOperations;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ScientificCalculator
{

    internal class Program
    {
        static bool dividebyzero = false;
        static bool isNextInput = false;              // for next input after an output
        static bool ScientificNotation = false;
        static bool memoryCheck = false;
        static bool Isfunction = false;

        static string currentInput = "";
        static string angleMeasureMode = "DEG";
        static string outputStatus = "F-E";

        static int angleModeTapCount = 0;
        static int outputCountTap = 0;
        static double memory = 0;
     
        static StringBuilder outputString = new StringBuilder();
        static void Main()
        {
            Console.Title = "Welcome To Scientific Calculator ";
            ConsoleKeyInfo input;
            bool sequentialOperatorCame;
            double result = 0;
            Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
            Console.WriteLine(outputString.ToString());
            while (true)
            {
                do
                {
                    input = Console.ReadKey(true);
                    sequentialOperatorCame = false;
                    Isfunction = false;
                    string currentstring = Value(input);
                    Console.Clear();
                    Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                    Console.WriteLine(outputString.ToString());

                    // for multiple sequential operator
                    if (IsOperator(currentstring) && outputString.Length != 0 && IsOperator(outputString[outputString.Length - 1].ToString()))
                    {
                        sequentialOperatorCame = true;
                        outputString.Remove(outputString.Length - 1, 1);
                        outputString.Append(currentstring);
                        Console.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.WriteLine(outputString.ToString());
                    }
                    // if starting input is operator , append 0 in output
                    else if (IsOperator(currentstring) && outputString.Length == 0)
                    {
                        sequentialOperatorCame = true;
                        outputString.Append("0");
                        outputString.Append(currentstring);
                        Console.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.WriteLine(outputString.ToString());
                    }
                    else
                    {
                        if (currentstring == "" && input.Key != ConsoleKey.Backspace)
                        {
                            continue;
                        }
                        string temp = currentstring;


                        outputString.Append(temp);
                        if (IsOperand(temp) && isNextInput == false)
                        {
                            currentInput += temp;

                        }
                        else
                        {
                            currentInput = "";

                        }
                        Console.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.WriteLine(outputString.ToString());

                    }
                    // 5+2=7, 8 previous result clear if we enter a operand
                    if (isNextInput == true)
                    {
                        if (outputString[outputString.Length - 1] >= '0' && outputString[outputString.Length - 1] <= '9' && Isfunction==false)
                        {
                            Console.Clear();
                            outputString.Clear();
                            Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                            Console.WriteLine(outputString.ToString());
                            outputString.Append(currentstring);
                            currentInput = currentstring;
                        }
                        isNextInput = false;
                    }
                    // printing third line i.e. output after entering input and '='
                    if (outputString.Length > 0 && sequentialOperatorCame == false && Isfunction == false)
                    {
                        Console.Write(currentInput);
                    }

                    if (input.Key == ConsoleKey.Backspace)
                    {
                        if (outputString.Length > 0)
                        {
                            outputString.Remove(outputString.Length - 1, 1);
                        }
                        Console.Clear();
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.Write(outputString.ToString());
                    }
                } while ((input.Key != ConsoleKey.Enter) && (input.Key != ConsoleKey.OemPlus));

                Console.Clear();
                if (outputString.Length > 0)
                {
                    try
                    {
                        result = arithmetic.Evaluate(outputString.ToString());
                        Console.WriteLine(angleMeasureMode + "\t" + outputStatus + "\t" + String.Format(memoryCheck ? "M" : ""));
                        Console.WriteLine(outputString.ToString() + "=");
                        if (ScientificNotation)
                        {
                            Console.Write(power.ChangeToScientificNotation(Convert.ToDouble(result)));
                        }
                        else
                        {
                            Console.WriteLine(result);
                        }
                    }
                    catch (DivideByZeroException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    outputString.Append(0);
                    Console.WriteLine(outputString.ToString() + "=");
                    Console.Write(0);
                }
                outputString.Clear();
                outputString.Append(result);
                currentInput = result.ToString();
                isNextInput = true;
            }
        }
        // To set the cursor position 
        static string GetNumericContentBeforeCursor()
        {
            int cursorLeftPosition = Console.CursorLeft;
            int cursorTopPosition = Console.CursorTop;

            StringBuilder capturedContent = new StringBuilder();

            for (int left = cursorLeftPosition - 1; left >= 0; left--)
            {
                char currentChar = Console.ReadKey().KeyChar;

                if (!(currentChar >= '0' && currentChar <= '9') || left == 0)
                    break;

                capturedContent.Insert(0, currentChar);

                // Move the cursor one position to the left
                Console.SetCursorPosition(left - 1, cursorTopPosition);
            }

            // Move the cursor back to its original position
            Console.SetCursorPosition(cursorLeftPosition, cursorTopPosition);

            return capturedContent.ToString();
        }

        static string Value(ConsoleKeyInfo inputKey)
        {
            switch (inputKey.Key)
            {
                case ConsoleKey.D:
                    if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Console.Write($"{outputString}dms({currentInput})");
                        return power.ConvertToDMS(Convert.ToDouble(currentInput)).ToString();
                    }
                    else
                    {
                        FormatInput();
                        Console.Write($"{outputString}deg({currentInput})");
                        return power.DMSToDegree(Convert.ToDouble(currentInput)).ToString();
                    }
                case ConsoleKey.M:
                    if (currentInput == "")
                    {
                        currentInput = "0";
                    }
                    if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)   //MS
                    {
                        memory = Convert.ToDouble(currentInput);
                        memoryCheck = true;
                        return "";
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0) //M+
                    {
                        memory += Convert.ToDouble(currentInput);
                        memoryCheck = true;
                        return "";
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)  //M-
                    {
                        memory -= Convert.ToDouble(currentInput);
                        memoryCheck = true;
                        return "";
                    }
                    else      //MR
                    {
                        if (memoryCheck == false)
                        {
                            return "";
                        }
                        else
                        {
                            if (memory >= 0)
                            {
                                return memory.ToString();
                            }
                            else
                                return "(" + memory.ToString() + ")";
                        }
                    }
                case ConsoleKey.B:  //MC
                    memory = 0;
                    memoryCheck = false;
                    return "";

                case ConsoleKey.S:
                    if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}sinh({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.SineHyp(newNumber, angleMeasureMode).ToString() + ")";
                        return tempValue;
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}sin^(-1)({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.SineInverse(newNumber, angleMeasureMode).ToString() + ")";
                        return tempValue;
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}sin({currentInput})");
                        string tempValue =  Trignometric_Operations.Sine(newNumber, angleMeasureMode).ToString() ;
                        return "(" + tempValue + ")";
                    }
                case ConsoleKey.Q:
                    if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Csch({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.CosecHyp(newNumber, angleMeasureMode).ToString() + ")";
                        return tempValue;
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Csc^(-1)({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.CosecInverse(newNumber, angleMeasureMode).ToString() + ")";
                        return tempValue;
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Csc({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.Cosec(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                case ConsoleKey.C:
                    if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Cosh({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.CosineHyp(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Cos^(-1)({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.CosineInverse(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Cos({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.Cosine(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                case ConsoleKey.T:
                    if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}tanh({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.TangentHyp(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}tan^(-1)({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.TangentInverse(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}tan({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.Tangent(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                case ConsoleKey.O:
                    if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Coth({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.CotHyp(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }

                    else if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Cot^(-1)({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.CotInverse(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Cot({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.Cot(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                case ConsoleKey.N:
                    if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Sech({currentInput})");
                        string tempValue = "(" + Trignometric_Operations.SecHyp(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Sec^(-1)({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.SecInverse(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                    else
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Sec({newNumber})");
                        string tempValue = "(" + Trignometric_Operations.Sec(newNumber, angleMeasureMode).ToString() + ")";
                        currentInput = "";
                        return tempValue;
                    }
                case ConsoleKey.Backspace: return "";
                case ConsoleKey.Enter: return "";
                case ConsoleKey.Add: return "+";
                case ConsoleKey.Subtract: return "-";
                case ConsoleKey.Multiply: return "*";
                case ConsoleKey.Divide: return "/";
                case ConsoleKey.Oem2: return "/";
                case ConsoleKey.OemPeriod: return ".";
                case ConsoleKey.D0:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return ")";
                    }
                    else
                    {
                        return "0";
                    }
                case ConsoleKey.D1: return "1";
                case ConsoleKey.D2: return "2";
                case ConsoleKey.D3: return "3";
                case ConsoleKey.D4: return "4";
                case ConsoleKey.D5:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "%";
                    }
                    else
                    {
                        return "5";
                    }
                case ConsoleKey.D6:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "^";
                    }
                    else
                    {
                        return "6";
                    }
                case ConsoleKey.D7:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "&";
                    }
                    else
                    {
                        return "7";
                    }
                case ConsoleKey.D8:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "*";
                    }
                    else
                    {
                        return "8";
                    }
                case ConsoleKey.D9:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        return "(";
                    }
                    else
                    {
                        return "9";
                    }
                case ConsoleKey.NumPad0: return "0";
                case ConsoleKey.NumPad1: return "1";
                case ConsoleKey.NumPad2: return "2";
                case ConsoleKey.NumPad3: return "3";
                case ConsoleKey.NumPad4: return "4";
                case ConsoleKey.NumPad5: return "5";
                case ConsoleKey.NumPad6: return "6";
                case ConsoleKey.NumPad7: return "7";
                case ConsoleKey.NumPad8: return "8";
                case ConsoleKey.NumPad9: return "9";
                case ConsoleKey.L:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        FormatInput();
                        Console.Write($"{outputString}log({currentInput})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = power.LogBase10(newNumber).ToString();
                        return ans;
                    }
                    else
                    {
                        FormatInput();
                        Console.Write($"{outputString}ln({currentInput})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = power.NaturalLog(newNumber).ToString();
                        return ans;
                    }
                case ConsoleKey.P:
                    if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)
                    {
                        string tempValue =  Math.PI.ToString() ;
                        return tempValue;
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)               //2^(x)
                    {
                        FormatInput ();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}2^({newNumber})");
                        string ans = power.Exponentiation(2, newNumber).ToString();
                        return ans;
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Control) != 0)                  //10^(x)
                    {
                        FormatInput () ;
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}10^({newNumber})");
                        string ans = power.Exponentiation(10, newNumber).ToString();
                        return ans;
                    }
                    else         //power                              
                    {
                        return "^";
                    }
                case ConsoleKey.V:
                    outputCountTap++;
                    if (outputCountTap == 0)
                    {
                        outputStatus = "F-E";
                        ScientificNotation = false;
                    }
                    else if (outputCountTap == 1)
                    {
                        outputStatus = "E-F";
                        ScientificNotation = true;
                    }
                    else if (outputCountTap == 2)
                    {
                        outputCountTap = 0;
                        ScientificNotation = false;
                        outputStatus = "F-E";
                    }
                    return "";
                case ConsoleKey.J:
                    if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)          // to find square root
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}√({newNumber})");
                        string ans = power.SquareRoot(newNumber).ToString();
                        return ans;                                                               
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)     // to find cube root
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}√({newNumber})");
                        string ans = power.CubeRoot(newNumber).ToString();
                        return ans;
                    }
                    else
                    {
                        return "";
                    }
              
                case ConsoleKey.R:
                    if ((inputKey.Modifiers & ConsoleModifiers.Alt) != 0)                    //to find cube
                    {
                        FormatInput();
                        Console.Write($"{outputString}cube({currentInput})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = power.Exponentiation(newNumber, 3).ToString();
                        return ans;                                                     
                    }
                    else if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)              //to find squre
                    {
                        FormatInput();
                        Console.Write($"{outputString}square({currentInput})");
                        Double.TryParse(currentInput, out double newNumber);
                        string ans = power.Exponentiation(newNumber, 2).ToString();
                        return ans;
                    }
                    else
                    {
                        return "";
                    }
                case ConsoleKey.G:         // to generate random value of any number (rand)
                    {
                        FormatInput();
                        double random = power.GenerateRandom();
                        Console.Write($"{random}");
                        return random.ToString();
                    }
                case ConsoleKey.Oem4:     // to print floor value of any number
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Floring({newNumber})");
                        string ans = power.FloorValue(newNumber).ToString();
                        return ans;
                    }
                case ConsoleKey.Oem6:      // to print ceiling value of any number
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}Ceiling({newNumber})");
                        string ans = power.CeilingValue(newNumber).ToString();
                        return ans;
                    }
                case ConsoleKey.F:        // to find factorial 
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}fact({newNumber})");
                        string ans = power.Factorial(newNumber).ToString();
                        return ans;
                    }
                case ConsoleKey.Z:
                    angleModeTapCount++;
                    if (angleModeTapCount == 0)
                    {
                        angleMeasureMode = "DEG";
                    }
                    else if (angleModeTapCount == 1)
                    {
                        angleMeasureMode = "RAD";
                    }
                    else if (angleModeTapCount == 2)
                    {
                        angleMeasureMode = "GRAD";
                    }
                    else if (angleModeTapCount == 3)
                    {
                        angleModeTapCount = 0;
                        angleMeasureMode = "DEG";
                    }
                    return "";
                case ConsoleKey.A:       // to find absoulute value
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}abs({newNumber})");
                        string ans = power.AbsoluteValue(newNumber).ToString();
                        return ans;
                    }
                case ConsoleKey.E:
                    if ((inputKey.Modifiers & ConsoleModifiers.Shift) != 0)            //e value
                    {
                        FormatInput();
                        Console.Write($"{outputString}e^({currentInput})");
                        return Math.E.ToString();
                    }
                    else                                                            //e^x
                    {
                        FormatInput();
                        Double.TryParse(currentInput, out double newNumber);
                        Console.Write($"{outputString}e^({newNumber})");
                        string ans = power.Exponential(Convert.ToDouble(newNumber)).ToString();
                        return ans;
                    }
                // Check for Esc key to terminate the program
                case ConsoleKey.Escape:
                    Environment.Exit(0);
                    return "";

                default: return "";
            }
            void FormatInput()
            {
                Isfunction = true;
                Console.Clear();
                outputString.Remove(outputString.Length - currentInput.Length, currentInput.Length);
            }
        }

        static bool IsOperator(string x)
        {
            return x == "+" || x == "-" || x == "*" || x == "/" || x == "^";
        }
        static bool IsOperand(string x)
        {
            return x == "0" || x == "1" || x == "2" || x == "3" || x == "4" || x == "5" || x == "6" || x == "7" || x == "8" || x == "9" || x == ".";
        }
    }
}

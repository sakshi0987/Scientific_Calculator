﻿using System;

namespace TrignometricOperations
{
    public class Trignometric_Operations
    {
        public static double AngleChanger(double angle, String Status)
        {
            if (Status == "DEG")
            {
                angle = (angle * Math.PI) / 180;
            }
            else if (Status == "GRAD")
            {
                angle = (angle * Math.PI) / 200;

            }
            return angle;
        }

        //Trignometric Function
        public static double Sine(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Sin(angle);

        }

        public static double Cosine(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Cos(angle);
        }

        public static double Tangent(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Tan(angle);
        }

        public static double Cot(double angle, String Status)
        {
            return 1 / Tangent(angle, Status);
        }

        public static double Sec(double angle, String Status)
        {
            return 1 / Cosine(angle, Status);
        }

        public static double Cosec(double angle, String Status)
        {
            return 1 / Sine(angle, Status);
        }

        //Inverse Trignometric Function
        public static double SineInverse(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Asin(angle);
        }

        public static double CosineInverse(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Acos(angle);
        }

        public static double TangentInverse(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Atan(angle);
        }

        public static double CotInverse(double angle, String Status)
        {
            return 1 / TangentInverse(angle, Status);
        }

        public static double SecInverse(double angle, String Status)
        {
            return 1 / CosineInverse(angle, Status);
        }

        public static double CosecInverse(double angle, String Status)
        {
            return 1 / SineInverse(angle, Status);
        }

        //Hyperbolic Function
        public static double SineHyp(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Sinh(angle);
        }

        public static double CosineHyp(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Cosh(angle);
        }

        public static double TangentHyp(double angle, String Status)
        {
            angle = AngleChanger(angle, Status);
            return Math.Tanh(angle);
        }
        public static double CotHyp(double angle, String Status)
        {
            return 1 / TangentHyp(angle, Status);
        }

        public static double SecHyp(double angle, String Status)
        {
            return 1 / CosineHyp(angle, Status);
        }

        public static double CosecHyp(double angle, String Status)
        {
            return 1 / SineHyp(angle, Status);
        }
    }
}
